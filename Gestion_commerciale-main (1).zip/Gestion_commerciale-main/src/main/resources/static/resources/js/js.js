var wwwpath = document.getElementById("globalpath").value;
wwwpath = wwwpath.slice(0, -1);