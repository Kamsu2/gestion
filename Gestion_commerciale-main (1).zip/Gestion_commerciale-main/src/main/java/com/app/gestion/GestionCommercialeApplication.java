package com.app.gestion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionCommercialeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionCommercialeApplication.class, args);
	}

}
