package com.app.gestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionCommercialeApplicationTests {

	@Test
	void contextLoads() {
	}

}
